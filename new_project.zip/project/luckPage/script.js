
$(document).ready(function () {
    localStorage.removeItem( 'selectedLuck' ); 
    firebase.auth().onAuthStateChanged(function (user) {
        if(user){
        var userPhoto = user.photoURL;
        var username = user.displayName;
        var dataWriter = document.getElementById('userImg');
        dataWriter.innerHTML = '<img src="' + userPhoto + '">';
        dataWriter = document.getElementById('topUserName')
        dataWriter.innerHTML = "Hello, " + username;
        }else{
          location.href = '../homepage/homepage.html'
        }
    });
    var btn1 = document.getElementById('b1');
    var luck1 = document.getElementById('luck1');
	var luck2 = document.getElementById('luck2');
    btn1.addEventListener('click', testF);


})

$('#b2').click(function () {
        location.href = '../Vacation_dates_confimation/vacation_dates.html'
});



$('#logOut').click(function () {
    firebase.auth().signOut().then(function () {
        // Sign-out successful.
        location.href = '../homepage/homepage.html'
    }, function (error) {
        // An error happened.
    });
})

